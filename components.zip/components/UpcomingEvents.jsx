export default function UpcomingEvents() {
  return (
    <section className="py-20">

      <h2 className="text-4xl font-bold text-center text-white mb-12">
        Upcoming Games
      </h2>

      <div className="bg-gradient-to-r from-red-600 via-purple-700 to-blue-800 
                      rounded-3xl p-10 shadow-2xl">

        <div className="grid md:grid-cols-3 gap-8">

          <GameCard
            date="Feb 5"
            team="West Elk vs Gunnison"
            time="7:00 PM"
          />

          <GameCard
            date="Feb 8"
            team="West Elk vs Aspen"
            time="6:00 PM"
          />

          <GameCard
            date="Feb 12"
            team="West Elk vs Telluride"
            time="8:00 PM"
          />

        </div>
      </div>
    </section>
  );
}

function GameCard({ date, team, time }) {
  return (
    <div className="bg-white rounded-2xl p-6 shadow-lg hover:scale-105 transition">

      <h3 className="text-xl font-bold text-gray-900">
        {date}
      </h3>

      <p className="mt-2 text-gray-800">
        {team}
      </p>

      <p className="text-gray-600 mt-1">
        {time}
      </p>
    </div>
  );
}